How to install:
1. move this whole folder to the desktop
2. run forge-1.20.1-47.3.10-installer.jar
3. open the minecraft launcher and launch forge (1.20.1)
4. close minecraft
5. open QModManager.exe
6. press launch and wait until the launcher opens
7. make sure everything has worked correctly
8. open the minecraft launcher again and launch the most recent VANILLA version (so that modded isnt the default)
9. add a shortcut to QModManager.exe to the desktop (Optional)



